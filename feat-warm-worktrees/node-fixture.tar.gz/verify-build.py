#!/usr/bin/env python3
import subprocess, time, json
from pathlib import Path
start=time.monotonic()
commands = [['/opt/homebrew/bin/npm', 'ci', '--offline', '--ignore-scripts', '--no-audit', '--no-fund'], ['/opt/homebrew/bin/npm', 'run', 'build']]
if Path('node_modules/fixture-math/index.js').exists(): commands=commands[1:]
with open('fixture-build.log','w') as log:
 for command in commands:
  result=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
  if result.returncode: break
record={'status':result.returncode,'buildSeconds':round(time.monotonic()-start,3)}
Path('build-result.json').write_text(json.dumps(record))
print(json.dumps(record))
raise SystemExit(result.returncode)
