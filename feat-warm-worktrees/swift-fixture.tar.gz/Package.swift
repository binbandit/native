// swift-tools-version: 6.2
import PackageDescription
let package = Package(name: "WarmFixture", products: [.executable(name: "warm-fixture", targets: ["WarmFixture"])], targets: [.executableTarget(name: "WarmFixture")])
