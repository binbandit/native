Run ./verify-build.py once when asked to build. Do not edit files. Use only offline commands.
