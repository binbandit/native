print((0..<20).reduce(0, +))
