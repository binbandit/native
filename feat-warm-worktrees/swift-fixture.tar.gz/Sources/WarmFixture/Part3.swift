struct Part3: Sendable { let values = Array(0..<100); func total() -> Int { values.reduce(0, +) } }
